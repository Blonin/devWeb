Groupe : Gustave Richter et Kenza Abdellaoui

Projet d'école

il faut utiliser les commande php -S localhost puis ouvrir son navigateur puis taper localhost

you need to make a database in phpmyadmin named login_db and another one named message_db
you need to change the user info to connect to the db in the process-contact.php and in the database.php to let the pages connect to the db 

Nous avons utilisé phpmyadmin pour enregistrer les utilisateurs ainsi que les messages envoyés il vous faudra donc faire 
deux base de donnée sur phpmyadmin pour faire fonctionner le site, un nommé login_db et l'autre message_db, il faudrat aussi laisse le site y acceder 
pour se faire changer les info de l'utilisateur dans les pages process-contact.php et database.php

Il sera fait en sorte que les bases de données soit construite automatiquement dès le lancement du site
avec une base de données "item-db.php" qui contiendra tout les objets etc

