Groupe : Gustave Richter et Kenza Abdellaoui

Projet d'école

il faut utiliser les commande php -S localhost puis ouvrir son navigateur puis taper localhost

L'ajout des objet a la base de donnée se fait dés le lancement du site mais ensuite
fais buggé le site puisque la commande est refaite sans vérification au préalable
pour ne plus faire buggé le site il faut commenter les lignes 102 jusqu'a 140 du fichier
"connect-bd.php" 

il aurait fallu faire des fonction en php et les appeller ensuite mais je n'ai pas 
commencé comme ça ce qui me fais perdre du temps et je devrais tout reprendre de zéro 
si je veux bien le faire 