<?php
    include_once("../php/session.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../index.css">
    <title>Sign up</title>
</head>
<body>
    
    <?php
    include("php/nav.php")
    ?>

    <div style="text-align: center;">
    <h1>Signup</h1>
    <p>Signup successful.</p>
    <p>You can now <a style="color: grey;" href="login.php">Log in</a></p></div>

</body>
</html>