<?php
    session_start();
?>

<html>
    <head>
        <title>Les irréductibles Palois</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="../css/general.css">
        <link rel="stylesheet" href="../css/contact.css">
    </head>

    <?php
        require 'header.php';
    ?>

    <body>
     	<?php
		require 'construction.php';
	?>
    </body>

    <?php
        require 'footer.htm';
    ?>
<html>
