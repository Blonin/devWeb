<div class="main-presentation" style="text-align: center;">
    <h1>Page en construction !</h1>
    <h2> toute plainte ou recommandation n'hésitez pas à nous <a href="/pages/contact.php">contacter ici</a></h2>
    <img src="/img/under_construction.gif" alt="under_construction" style="margin: 20px 25%; width: 50%;">
</div>