Groupe : Gustave Richter et Kenza Abdellaoui
Nous etions venu vous voir dans votre bureau par rapport a la suppression complet du site

Il suffit d'ouvrir le fichier index.html dans votre navigateur pour ouvrir le site

Projet d'école
